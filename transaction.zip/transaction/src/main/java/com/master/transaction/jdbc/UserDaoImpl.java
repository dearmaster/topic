package com.master.transaction.jdbc;

import java.sql.Types;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class UserDaoImpl extends JdbcDaoSupport implements UserDao {
	
	private static final String USER_BALANCE_DEPOSIT_SQL = "update user_balance_tbl set balance = balance + ? where username = ?";
	private static final String USER_BALANCE_WITHDRAW_SQL = "update user_balance_tbl set balance = balance - :amount where username = :username";
	private static final String USER_BALANCE_QUERY_SQL = "select * from user_balance_tbl where username = :username";

	@Override
	public void deposit(User user, double amount) {
		this.getJdbcTemplate().update(USER_BALANCE_DEPOSIT_SQL, new Object[]{amount, user.getUsername()}, new Object[]{Types.DOUBLE, Types.VARCHAR});
	}

	@Override
	public void withdraw(User user, double amount) {
		
	}

	@Override
	public Double getBalance(User user) {
		return null;
	}

}
